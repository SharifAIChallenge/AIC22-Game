run this command:
chmod +x ./AIC_Graphic_Linux.x86_64
